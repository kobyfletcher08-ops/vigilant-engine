'use client';
import {useEffect,useState} from 'react';
import {Check,SlidersHorizontal,RefreshCw} from 'lucide-react';
import {validateRpcSettings,type RpcSettings} from '../lib/rpc-settings';
import type {Config} from '../lib/model';
export default function RpcSettingsPanel({config,blocked,onSave,onCheck}:{config:Config,blocked:boolean,onSave:(config:Config)=>void,onCheck:()=>void}){
 const [settings,setSettings]=useState<RpcSettings>(()=>validateRpcSettings(config.rpcSettings));
 useEffect(()=>setSettings(validateRpcSettings(config.rpcSettings)),[config]);
 return <section className="panel padded rpc-tuning"><div className="panel-top"><h2>RPC pacing & skipped pools</h2><SlidersHorizontal size={18}/></div><p>Continue past failed pool reads and token quotes. Failed entries remain in the catalog or retry list, and do not count as qualifying routes.</p>
  <form onSubmit={e=>{e.preventDefault();onSave({...config,rpcSettings:settings});}}><label className="check-label"><input type="checkbox" checked={settings.skipFailedPools} onChange={e=>setSettings({...settings,skipFailedPools:e.target.checked})}/>Skip failed pools and token quotes</label><p className="hint">Disable this to pause at the first temporary pool-read failure. Network and factory setup checks must still pass. Transaction simulation and signing checks remain required.</p>
   <div className="form-grid"><label>RPC calls per batch<select value={settings.batchSize} onChange={e=>setSettings({...settings,batchSize:Number(e.target.value)})}><option value={4}>4 · smaller batches</option><option value={8}>8 · balanced</option><option value={16}>16 · larger batches</option></select></label><label>Factory pairs per page<select value={settings.pageSize} onChange={e=>setSettings({...settings,pageSize:Number(e.target.value)})}>{[8,16,32].map(n=><option key={n} value={n}>{n} pairs</option>)}</select></label></div><label>Delay between RPC batches (milliseconds)<input type="number" min={0} max={2000} step={50} value={settings.delayMs} onChange={e=>setSettings({...settings,delayMs:Number(e.target.value)})}/></label>
   <div className="button-row"><button className="primary" disabled={blocked} type="submit"><Check size={14}/> Save RPC settings</button><button type="button" onClick={()=>setSettings({...settings,batchSize:4,delayMs:500,pageSize:8})}>Gentle preset</button><button type="button" disabled={blocked} onClick={onCheck}><RefreshCw size={14}/> Check RPC</button></div>
  </form><p className="hint">Changing pacing keeps the saved catalog cursor. Use Recheck page for skipped pools or Retry failed quotes for token quote failures. A proxy or separate hosting is not required.</p>
 </section>;
}
